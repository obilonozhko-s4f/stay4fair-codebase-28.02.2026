<?php
// MU loader for "All Apartments on the Map"
require_once __DIR__ . '/all-apartments-on-the-map/all-apartments-on-the-map.php';
