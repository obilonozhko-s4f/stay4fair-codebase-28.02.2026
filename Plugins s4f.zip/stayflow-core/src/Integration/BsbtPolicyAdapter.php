<?php

declare(strict_types=1);

namespace StayFlow\Integration\Adapters;

/**
 * RU: TODO Каркас адаптера политик BSBT (неактивный).
 * EN: TODO BSBT policy adapter scaffold (inactive).
 */
final class BsbtPolicyAdapter
{
}
