<?php

declare(strict_types=1);

namespace StayFlow\Integration\Adapters;

/**
 * RU: TODO Каркас адаптера ставок BSBT (неактивный).
 * EN: TODO BSBT rates adapter scaffold (inactive).
 */
final class BsbtRatesAdapter
{
}
