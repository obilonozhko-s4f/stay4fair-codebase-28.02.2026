<?php

declare(strict_types=1);

namespace StayFlow\Integration\Adapters;

/**
 * RU: TODO Каркас адаптера контента BSBT (неактивный).
 * EN: TODO BSBT content adapter scaffold (inactive).
 */
final class BsbtContentAdapter
{
}
