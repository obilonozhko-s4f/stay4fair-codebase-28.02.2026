<?php

declare(strict_types=1);

namespace StayFlow\Integration\Adapters;

/**
 * RU: TODO Каркас адаптера Owner Portal (неактивный).
 * EN: TODO Owner Portal adapter scaffold (inactive).
 */
final class OwnerPortalAdapter
{
}
